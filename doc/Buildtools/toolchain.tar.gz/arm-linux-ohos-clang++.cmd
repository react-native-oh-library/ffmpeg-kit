@echo off
setlocal

if "%1" == "-cc1" goto :H

set _BIN_DIR=%~dp0
set "_BIN_DIR=" && "%_BIN_DIR%clang++.exe" --target=arm-linux-ohos %*
if ERRORLEVEL 1 exit /b 1
goto :done

:H
rem Target is already an argument.
set "_BIN_DIR=" && "%_BIN_DIR%clang++.exe" %*
if ERRORLEVEL 1 exit /b 1
goto :done

:done
